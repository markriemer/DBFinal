-- MySQL dump 10.15  Distrib 10.0.27-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: zippy
-- ------------------------------------------------------
-- Server version	10.0.27-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Test`
--

DROP TABLE IF EXISTS `Test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Test` (
  `cash` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Test`
--

LOCK TABLES `Test` WRITE;
/*!40000 ALTER TABLE `Test` DISABLE KEYS */;
/*!40000 ALTER TABLE `Test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (1,'Pat Frank '),(2,'J. Delgado-Figueroa '),(3,'Michael Avallone '),(4,'M. V. Carey '),(5,'Lancaster '),(6,'Joan Kahn '),(7,'Alfred Hitchcock '),(8,'Mary Danby '),(9,'Alfred Hitchcock '),(10,'Dorothy Eden ');
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `books` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `pub_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`book_id`),
  KEY `pub_id` (`pub_id`),
  CONSTRAINT `books_ibfk_1` FOREIGN KEY (`pub_id`) REFERENCES `publishers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=258 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'Alas, Babylon',2),(2,'Flamingoes on the Lake',3),(3,'Daughter of darkness',7),(4,'Alfred Hitchcock and the three investigators in Th',5),(5,'Temptation',1),(6,'Some things strange and sinister',2),(7,'Let it all bleed out',2),(8,'The Irresistible Force',6),(9,'The fifth Fontana book of great horror stories',2),(10,'Alfred Hitchcock presents slay ride',8),(11,'The shadow wife.',9),(12,'The little adventure',10),(13,'The devil in love',8),(14,'More tales to tremble by',4),(15,'A gift for a lion.',7),(16,'French Country Cooking, etc',1),(17,'Luv',8),(18,'Lady Audley\'s secret',2),(19,'The old school tie',9),(20,'Leica Fotografie',3),(21,'In spite of all terror',5),(22,'Our lady of darkness',2),(23,'Little big man.',7),(24,'A Stranger in My Grave',6),(25,'The criminal C.O.D.',6),(26,'The Blue Max',1),(27,'Widow of Windsor',10),(28,'The gold shoe',5),(29,'Passions in the Sand',9),(30,'The shining years',7),(31,'A hero of our time',8),(32,'The eccentricities of a nightingale',3),(33,'You\'re stepping on my cloak and dagger.',1),(34,'To Live Again',7),(35,'U-boats at war.',1),(36,'Faust',8),(37,'The two deaths of Christopher Martin.',6),(38,'An unknown Welshman',10),(39,'Meaning in the visual arts: papers in and on art h',3),(40,'You and your lucky stars',2),(41,'Our man in Havana',8),(42,'Something for the medicine man.',5),(43,'The Old West speaks.',9),(44,'The deathmakers.',4),(45,'Caste and class in a southern town.',8),(46,'The bitter conquest',1),(47,'The golden book encyclopedia',3),(48,'The Livittowners',6),(49,'So, What\'s the Difference?',3),(50,'The killing of Richard the Third.',5),(51,'The victim',7),(52,'Philosophical letters.',3),(53,'Wake in fright.',10),(54,'Tony',7),(55,'Cover-up',1),(56,'Enough',9),(57,'The kindly ones.',9),(58,'Unwanted sex',6),(59,'Escape from Colditz',8),(60,'The sign of four',7),(61,'Linnet.',9),(62,'Smear job',2),(63,'Within the hollow crown',6),(64,'Thin films',9),(65,'The business of crime',9),(66,'Andy Buckram\'s tin men',9),(67,'The House Called Sakura (Harlequin Romance, 1892)',9),(68,'A kiss for the King',6),(69,'As eagles fly',8),(70,'El cuento',9),(71,'The listeners',5),(72,'Jewelled path',10),(73,'Homo ludens',5),(74,'Devil\'s Match',9),(75,'Anatomy of the law',7),(76,'Islandia',7),(77,'The comedians.',9),(78,'Lucky Starr and the rings of Saturn',5),(79,'Murder, inc',3),(80,'The glass heiress',6),(81,'Robots, Androids, and Mechanical Oddities',3),(82,'The nine mile walk',5),(83,'The dyadic cyclone',9),(84,'A Dictionary of American idioms',10),(85,'Brighton rock',1),(86,'First love',7),(87,'Cane',4),(88,'The North Avenue irregulars',2),(89,'The cosmic rape',8),(90,'Abattoir 5 ou la croisade des enfants',4),(91,'The day of the locust',7),(92,'Whim to kill',5),(93,'No holiday for crime',1),(94,'Unexpected death',4),(95,'The defense',4),(96,'Leslie Charteris\' The Saint and the Hapsburg neckl',3),(97,'Sue Barton, visiting nurse',6),(98,'The puppet masters',6),(99,'The pilgrim\'s regress',10),(100,'The fox from his lair',4),(101,'The private life of the rabbit',10),(102,'The smiling Medusa.',7),(103,'Scarlet sails',2),(104,'How many miles to Sundown.',3),(105,'A blunt instrument',1),(106,'Three for the money',7),(107,'$tealing $amantha',8),(108,'Holy housewifery',1),(109,'God speaks in my life',3),(110,'Iroquois',4),(111,'The gaudy shadows',9),(112,'Lots of love, Lucinda.',10),(113,'Include me out! Confessions of an ecclesiastical c',2),(114,'The brothel in Rosenstrasse',10),(115,'Goodbye Delaney',7),(116,'The green berets.',3),(117,'A passage to India.',3),(118,'A bullet for Cinderella',9),(119,'High Sierra',8),(120,'Gedreven door verlangen',8),(121,'Year of consent',4),(122,'The World of Odysseus',10),(123,'The wizard\'s daughter',9),(124,'Witchcraft',10),(125,'Why shoot a butler?',10),(126,'What\'s a girl to do?',4),(127,'What happened to Amy?',5),(128,'The haunted cove',1),(129,'The walnut tree',2),(130,'The unknown Ajax',5),(131,'Under the net',7),(132,'The tragedy of King Lear',4),(133,'Tough trip through paradise, 1878-1879.',8),(134,'That man from Texas',2),(135,'Tarot classic',10),(136,'The tastemakers.',5),(137,'Tales of time and space',7),(138,'A study of poetry',6),(139,'Strike first!',7),(140,'Street corner society',10),(141,'Stories',10),(142,'Something up a sleeve.',2),(143,'Small world',9),(144,'The social sources of denominationalism.',8),(145,'Sociology of deviant behavior',7),(146,'Single File',9),(147,'Shatner',3),(148,'The Seasick whale',6),(149,'Sea Jade',3),(150,'Rosa Luxemburg speaks',2),(151,'The Rising Gorge',8),(152,'A review of Spanish',9),(153,'The rest of the robots.',9),(154,'Red River',3),(155,'The red orchestra',1),(156,'The race for love',2),(157,'The process and effects of mass communication.',4),(158,'The politics of experience, and, The bird of parad',6),(159,'Playboy\'s host & bar book.',2),(160,'Person to person',5),(161,'The pawnbroker',4),(162,'Paper sheriff',8),(163,'Palmistry made practical',7),(164,'Operation pax',6),(165,'The Orthodox Church.',4),(166,'Nineteen nineteen',5),(167,'Nicholas and Alexandra',8),(168,'Night walker',9),(169,'Nevada',9),(170,'Mystery of the green cat',9),(171,'Murder at Hazelmoor',7),(172,'The most of P. G. Wodehouse.',4),(173,'Mood indigo.',3),(174,'More of the Best',8),(175,'Midsummer masque',9),(176,'Ma Rainey\'s black bottom',4),(177,'Mama\'s bank account',2),(178,'Magic tricks',6),(179,'Magic Elizabeth',2),(180,'Macramé.',6),(181,'The machine in the garden',3),(182,'The little wax doll',10),(183,'Living on the growing edge',8),(184,'The Lazlo letters',9),(185,'A lantern in her hand',6),(186,'Last exit to Brooklyn',3),(187,'Lady Jane\'s ribbons',4),(188,'Just Morgan',3),(189,'I was dancing.',8),(190,'The Indian heritage of America',2),(191,'If I die in a combat zone',10),(192,'The ice-cold nude',1),(193,'How the other half lives',9),(194,'How I lost 36,000 pounds',1),(195,'The house in Paris',4),(196,'How firm a foundation',4),(197,'Horror at the Hacienda',6),(198,'A history of the Jews.',8),(199,'A hero of our time',4),(200,'A handful of dust',3),(201,'The green eagle score',3),(202,'The Greek passion',2),(203,'The good soldier',8),(204,'Goldmine',10),(205,'The Golovlovs',3),(206,'The glass inferno',10),(207,'Gloriana, or The Unfulfill\'d Queen',6),(208,'The genius and the goddess',1),(209,'Galactic patrol',3),(210,'Galaxies like grains of sand',1),(211,'Free fall',4),(212,'Fraternity of the weird',5),(213,'For whom the bell tolls',2),(214,'Flash and filigree',3),(215,'Five go to Demon\'s Rocks',10),(216,'Farnham\'s freehold',3),(217,'The family',10),(218,'Fantasia mathematica; being a set of stories, toge',1),(219,'Fabric Of Love',8),(220,'Experiment in crime',5),(221,'England swings SF',7),(222,'Dream dancer',9),(223,'The  dispossessed',7),(224,'The devil tree',3),(225,'Democracy and the student left',8),(226,'Decline and fall',9),(227,'The deathworms of Kratos',9),(228,'The daughter of time',8),(229,'The dark of memory',8),(230,'Darkover landfall',9),(231,'Danny Dunn and the homework machine',6),(232,'Cours supérieur de français',10),(233,'The corridors of time',2),(234,'Cloud 9',7),(235,'Close relations',5),(236,'China court',9),(237,'A child\'s garden of grass',6),(238,'Catch and saddle',4),(239,'Cats',10),(240,'Carmilla',6),(241,'The candid impostor.',1),(242,'Calico bush',3),(243,'Buchanan\'s gun',9),(244,'Brinkley Manor',6),(245,'Bomber',10),(246,'The blackboard jungle',8),(247,'Behold, here\'s poison',6),(248,'The barren beaches of hell',2),(249,'Ballet',2),(250,'Athena\'s Airs',4),(251,'April morning',10),(252,'Ape and essence.',4),(253,'And be a villain',3),(254,'The anatomy of revolution',1),(255,'The alchemist.',8),(256,'The Saint in Miami',4),(257,'The Fettered Past',4);
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkouts`
--

DROP TABLE IF EXISTS `checkouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checkouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `returned_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `checkouts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `checkouts_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkouts`
--

LOCK TABLES `checkouts` WRITE;
/*!40000 ALTER TABLE `checkouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `checkouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discusses`
--

DROP TABLE IF EXISTS `discusses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discusses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `post_time` datetime NOT NULL,
  `post_text` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `discusses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `discusses_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discusses`
--

LOCK TABLES `discusses` WRITE;
/*!40000 ALTER TABLE `discusses` DISABLE KEYS */;
/*!40000 ALTER TABLE `discusses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follows`
--

DROP TABLE IF EXISTS `follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `follows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `follows_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `follows_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follows`
--

LOCK TABLES `follows` WRITE;
/*!40000 ALTER TABLE `follows` DISABLE KEYS */;
/*!40000 ALTER TABLE `follows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publishers`
--

DROP TABLE IF EXISTS `publishers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publishers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publishers`
--

LOCK TABLES `publishers` WRITE;
/*!40000 ALTER TABLE `publishers` DISABLE KEYS */;
INSERT INTO `publishers` VALUES (1,'Bantam Books'),(2,'Writers Club Press'),(3,'New American Library'),(4,'Scholastic'),(5,'Warner Books'),(6,'Avon Books'),(7,'Dell'),(8,'Bantam Books'),(9,'Beagle Books'),(10,'Dell Pub. Co.');
/*!40000 ALTER TABLE `publishers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wrote`
--

DROP TABLE IF EXISTS `wrote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wrote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `book_id` (`book_id`),
  CONSTRAINT `wrote_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`),
  CONSTRAINT `wrote_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`)
) ENGINE=InnoDB AUTO_INCREMENT=258 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wrote`
--

LOCK TABLES `wrote` WRITE;
/*!40000 ALTER TABLE `wrote` DISABLE KEYS */;
INSERT INTO `wrote` VALUES (1,3,257),(2,1,1),(3,1,2),(4,3,3),(5,10,4),(6,8,5),(7,4,6),(8,6,7),(9,5,8),(10,9,9),(11,2,10),(12,6,11),(13,3,12),(14,2,13),(15,2,14),(16,8,15),(17,5,16),(18,6,17),(19,5,18),(20,7,19),(21,2,20),(22,2,21),(23,3,22),(24,8,23),(25,10,24),(26,8,25),(27,5,26),(28,5,27),(29,7,28),(30,10,29),(31,8,30),(32,9,31),(33,10,32),(34,5,33),(35,5,34),(36,4,35),(37,8,36),(38,10,37),(39,7,38),(40,10,39),(41,7,40),(42,7,41),(43,6,42),(44,5,43),(45,3,44),(46,10,45),(47,1,46),(48,10,47),(49,5,48),(50,5,49),(51,9,50),(52,10,51),(53,10,52),(54,1,53),(55,4,54),(56,6,55),(57,6,56),(58,10,57),(59,7,58),(60,9,59),(61,1,60),(62,8,61),(63,8,62),(64,10,63),(65,6,64),(66,4,65),(67,3,66),(68,1,67),(69,2,68),(70,10,69),(71,3,70),(72,3,71),(73,4,72),(74,6,73),(75,10,74),(76,4,75),(77,9,76),(78,9,77),(79,7,78),(80,7,79),(81,10,80),(82,5,81),(83,6,82),(84,3,83),(85,1,84),(86,5,85),(87,1,86),(88,1,87),(89,6,88),(90,4,89),(91,10,90),(92,8,91),(93,6,92),(94,9,93),(95,4,94),(96,5,95),(97,6,96),(98,2,97),(99,2,98),(100,9,99),(101,5,100),(102,5,101),(103,10,102),(104,9,103),(105,5,104),(106,8,105),(107,8,106),(108,1,107),(109,5,108),(110,9,109),(111,6,110),(112,5,111),(113,9,112),(114,2,113),(115,10,114),(116,3,115),(117,1,116),(118,1,117),(119,3,118),(120,1,119),(121,9,120),(122,9,121),(123,2,122),(124,6,123),(125,4,124),(126,5,125),(127,4,126),(128,4,127),(129,1,128),(130,4,129),(131,6,130),(132,5,131),(133,9,132),(134,4,133),(135,9,134),(136,3,135),(137,10,136),(138,5,137),(139,7,138),(140,6,139),(141,1,140),(142,6,141),(143,4,142),(144,4,143),(145,5,144),(146,8,145),(147,9,146),(148,10,147),(149,7,148),(150,4,149),(151,6,150),(152,6,151),(153,2,152),(154,4,153),(155,9,154),(156,3,155),(157,2,156),(158,4,157),(159,1,158),(160,4,159),(161,8,160),(162,8,161),(163,2,162),(164,3,163),(165,9,164),(166,5,165),(167,8,166),(168,4,167),(169,5,168),(170,9,169),(171,7,170),(172,2,171),(173,9,172),(174,4,173),(175,7,174),(176,3,175),(177,8,176),(178,8,177),(179,6,178),(180,1,179),(181,1,180),(182,1,181),(183,6,182),(184,1,183),(185,2,184),(186,9,185),(187,3,186),(188,9,187),(189,6,188),(190,5,189),(191,6,190),(192,6,191),(193,8,192),(194,4,193),(195,7,194),(196,3,195),(197,4,196),(198,7,197),(199,3,198),(200,5,199),(201,1,200),(202,1,201),(203,9,202),(204,2,203),(205,5,204),(206,5,205),(207,1,206),(208,2,207),(209,9,208),(210,5,209),(211,1,210),(212,9,211),(213,9,212),(214,3,213),(215,4,214),(216,1,215),(217,5,216),(218,3,217),(219,4,218),(220,1,219),(221,8,220),(222,5,221),(223,8,222),(224,8,223),(225,10,224),(226,2,225),(227,3,226),(228,7,227),(229,6,228),(230,8,229),(231,4,230),(232,4,231),(233,1,232),(234,7,233),(235,6,234),(236,4,235),(237,1,236),(238,5,237),(239,4,238),(240,8,239),(241,6,240),(242,5,241),(243,4,242),(244,3,243),(245,3,244),(246,4,245),(247,3,246),(248,4,247),(249,5,248),(250,1,249),(251,10,250),(252,7,251),(253,2,252),(254,1,253),(255,6,254),(256,2,255),(257,5,256);
/*!40000 ALTER TABLE `wrote` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-15 14:23:46
